/* =========================================================
   GEPGEO — script.js
   Funcionalidades globais do site (todas as páginas)
   ========================================================= */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    setYear();
    initLanguageSwitch();
    initMobileMenu();
    initSearch();
    initBackToTop();
    initAccordion();
    initFilterBar();
    initGallery();
    initPostToggle();
    initContactForm();
    initBudgetForm();
    initScheduleForm();
  }

  /* ---------- Ano automático no rodapé ---------- */
  function setYear() {
    var el = document.getElementById("year");
    if (el) el.textContent = new Date().getFullYear();
  }

  /* ---------- Idioma PT / EN ---------- */
  var LANG_KEY = "gepgeo_lang";

  function initLanguageSwitch() {
    var saved = localStorage.getItem(LANG_KEY) || "pt";
    applyLanguage(saved);

    var buttons = document.querySelectorAll("[data-set-lang]");
    buttons.forEach(function (btn) {
      btn.addEventListener("click", function () {
        applyLanguage(btn.getAttribute("data-set-lang"));
      });
    });
  }

  function applyLanguage(lang) {
    if (lang !== "pt" && lang !== "en") lang = "pt";
    document.documentElement.setAttribute("lang", lang);
    localStorage.setItem(LANG_KEY, lang);

    document.querySelectorAll("[data-set-lang]").forEach(function (btn) {
      var isActive = btn.getAttribute("data-set-lang") === lang;
      btn.setAttribute("aria-pressed", isActive ? "true" : "false");
    });

    document.querySelectorAll("[data-lang-placeholder-pt]").forEach(function (input) {
      var attr = "data-lang-placeholder-" + lang;
      var value = input.getAttribute(attr);
      if (value) input.setAttribute("placeholder", value);
    });

    document.documentElement.setAttribute("data-current-lang", lang);
  }

  /* ---------- Menu mobile ---------- */
  function initMobileMenu() {
    var toggle = document.getElementById("menuToggle");
    var links = document.getElementById("navLinks");
    if (!toggle || !links) return;

    toggle.addEventListener("click", function () {
      var isOpen = links.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    links.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        links.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ---------- Pesquisa ---------- */
  var SEARCH_INDEX = [
    { pt: "Levantamento Topográfico", en: "Topographic Surveying", url: "servicos.html#topografia" },
    { pt: "Implantação", en: "Site Setting-out", url: "servicos.html#topografia" },
    { pt: "Georreferenciamento", en: "Georeferencing", url: "servicos.html#topografia" },
    { pt: "Nivelamento", en: "Levelling", url: "servicos.html#topografia" },
    { pt: "Cálculo de Volumes", en: "Volume Calculation", url: "servicos.html#topografia" },
    { pt: "Geoprocessamento / SIG / GIS", en: "Geoprocessing / GIS", url: "servicos.html#geoprocessamento" },
    { pt: "Mapeamento com Drone", en: "Drone Mapping", url: "servicos.html#geoprocessamento" },
    { pt: "Fiscalização e Apoio Técnico", en: "Supervision & Technical Support", url: "servicos.html#fiscalizacao" },
    { pt: "Formação Profissional", en: "Professional Training", url: "servicos.html#formacao" },
    { pt: "Fazenda Bela Vista — Ambriz", en: "Bela Vista Farm — Ambriz", url: "portfolio.html" },
    { pt: "Loteamento Kilamba", en: "Kilamba Subdivision", url: "portfolio.html" },
    { pt: "EN240 — Fiscalização Ferroviária", en: "EN240 — Railway Supervision", url: "portfolio.html" },
    { pt: "Pedir Orçamento", en: "Request a Quote", url: "orcamento.html" },
    { pt: "Agendar Serviço", en: "Schedule a Service", url: "agendamento.html" },
    { pt: "Contactos", en: "Contact", url: "contactos.html" },
    { pt: "FAQ / Perguntas Frequentes", en: "FAQ", url: "faq.html" },
    { pt: "Área do Cliente", en: "Client Area", url: "area-cliente.html" }
  ];

  function initSearch() {
    var toggle = document.getElementById("searchToggle");
    var panel = document.getElementById("searchPanel");
    var form = document.getElementById("searchForm");
    var input = document.getElementById("searchInput");
    var results = document.getElementById("searchResults");
    if (!toggle || !panel) return;

    toggle.addEventListener("click", function () {
      var isOpen = panel.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      if (isOpen && input) input.focus();
    });

    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        renderResults(input.value.trim());
      });
    }

    if (input) {
      input.addEventListener("input", function () {
        renderResults(input.value.trim());
      });
    }

    function renderResults(query) {
      if (!results) return;
      results.innerHTML = "";
      if (!query) return;

      var lang = document.documentElement.getAttribute("lang") || "pt";
      var q = query.toLowerCase();
      var matches = SEARCH_INDEX.filter(function (item) {
        return item.pt.toLowerCase().indexOf(q) !== -1 || item.en.toLowerCase().indexOf(q) !== -1;
      });

      if (matches.length === 0) {
        var empty = document.createElement("div");
        empty.className = "search-empty";
        empty.textContent = lang === "en" ? "No results found." : "Nenhum resultado encontrado.";
        results.appendChild(empty);
        return;
      }

      matches.forEach(function (item) {
        var a = document.createElement("a");
        a.href = item.url;
        a.innerHTML = (lang === "en" ? item.en : item.pt) + "<small>" + item.url + "</small>";
        results.appendChild(a);
      });
    }
  }

  /* ---------- Botão voltar ao topo ---------- */
  function initBackToTop() {
    var btn = document.getElementById("backToTop");
    if (!btn) return;

    window.addEventListener("scroll", function () {
      if (window.scrollY > 500) {
        btn.classList.add("is-visible");
      } else {
        btn.classList.remove("is-visible");
      }
    });

    btn.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  /* ---------- Acordeão de FAQ ---------- */
  function initAccordion() {
    var items = document.querySelectorAll(".accordion-item__q");
    items.forEach(function (btn) {
      btn.addEventListener("click", function () {
        var item = btn.closest(".accordion-item");
        var isOpen = item.getAttribute("aria-expanded") === "true";
        item.setAttribute("aria-expanded", isOpen ? "false" : "true");
        btn.setAttribute("aria-expanded", isOpen ? "false" : "true");
      });
    });
  }

  /* ---------- Barra de filtros (portfólio / blog / galeria) ---------- */
  function initFilterBar() {
    var bars = document.querySelectorAll(".filter-bar");
    bars.forEach(function (bar) {
      var buttons = bar.querySelectorAll("button");
      var targetSelector = bar.getAttribute("data-filter-target");
      if (!targetSelector) return;

      buttons.forEach(function (btn) {
        btn.addEventListener("click", function () {
          buttons.forEach(function (b) { b.setAttribute("aria-pressed", "false"); });
          btn.setAttribute("aria-pressed", "true");

          var filter = btn.getAttribute("data-filter");
          document.querySelectorAll(targetSelector).forEach(function (card) {
            var category = card.getAttribute("data-category");
            var show = filter === "all" || filter === category;
            card.style.display = show ? "" : "none";
          });
        });
      });
    });
  }

  /* ---------- Galeria + Lightbox ---------- */
  function initGallery() {
    var items = document.querySelectorAll(".gallery__item");
    var lightbox = document.querySelector(".lightbox");
    if (!items.length || !lightbox) return;

    var img = lightbox.querySelector("img");
    var caption = lightbox.querySelector(".lightbox__caption");
    var closeBtn = lightbox.querySelector(".lightbox__close");
    var prevBtn = lightbox.querySelector(".lightbox__nav--prev");
    var nextBtn = lightbox.querySelector(".lightbox__nav--next");
    var current = 0;
    var list = Array.prototype.slice.call(items);

    function open(index) {
      current = index;
      var el = list[current];
      var src = el.querySelector("img").getAttribute("src");
      img.setAttribute("src", src);
      if (caption) caption.textContent = el.getAttribute("data-caption") || "";
      lightbox.classList.add("is-open");
    }

    function close() {
      lightbox.classList.remove("is-open");
    }

    function nav(step) {
      current = (current + step + list.length) % list.length;
      open(current);
    }

    list.forEach(function (el, index) {
      el.addEventListener("click", function () { open(index); });
    });
    if (closeBtn) closeBtn.addEventListener("click", close);
    if (prevBtn) prevBtn.addEventListener("click", function () { nav(-1); });
    if (nextBtn) nextBtn.addEventListener("click", function () { nav(1); });
    lightbox.addEventListener("click", function (e) {
      if (e.target === lightbox) close();
    });
    document.addEventListener("keydown", function (e) {
      if (!lightbox.classList.contains("is-open")) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") nav(-1);
      if (e.key === "ArrowRight") nav(1);
    });
  }

  /* ---------- Ver mais (blog / notícias) ---------- */
  function initPostToggle() {
    document.querySelectorAll(".post-card__more").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var card = btn.closest(".post-card");
        var full = card ? card.querySelector(".post-full") : null;
        if (!full) return;
        full.classList.toggle("is-open");
      });
    });
  }

  /* ---------- Formulário de contacto (envio por email via API gratuita) ---------- */
  function initContactForm() {
    bindFormmailForm("contactForm", "contactStatus");
  }

  /* ---------- Formulário de orçamento ---------- */
  function initBudgetForm() {
    bindFormmailForm("budgetForm", "budgetStatus");
  }

  /* ---------- Formulário de agendamento ---------- */
  function initScheduleForm() {
    bindFormmailForm("scheduleForm", "scheduleStatus");
  }

  /* Envio genérico via Web3Forms (API gratuita) — configurar access_key na próxima etapa */
  function bindFormmailForm(formId, statusId) {
    var form = document.getElementById(formId);
    var status = document.getElementById(statusId);
    if (!form) return;

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var lang = document.documentElement.getAttribute("lang") || "pt";

      showStatus(status, "info", lang === "en" ? "Sending…" : "A enviar…");

      var data = new FormData(form);

      fetch("https://api.web3forms.com/submit", {
        method: "POST",
        body: data,
        headers: { Accept: "application/json" }
      })
        .then(function (res) { return res.json(); })
        .then(function (json) {
          if (json.success) {
            showStatus(status, "success",
              lang === "en"
                ? "Message sent successfully! We will get back to you shortly."
                : "Mensagem enviada com sucesso! Entraremos em contacto brevemente.");
            form.reset();
          } else {
            showStatus(status, "error",
              lang === "en"
                ? "Something went wrong. Please try again or contact us via WhatsApp."
                : "Ocorreu um erro. Tente novamente ou contacte-nos via WhatsApp.");
          }
        })
        .catch(function () {
          showStatus(status, "error",
            lang === "en"
              ? "Connection error. Please try again or contact us via WhatsApp."
              : "Erro de ligação. Tente novamente ou contacte-nos via WhatsApp.");
        });
    });
  }

  function showStatus(el, type, message) {
    if (!el) return;
    el.textContent = message;
    el.className = "form-status is-visible " + type;
  }
})();
